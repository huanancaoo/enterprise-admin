import { execFileSync } from "node:child_process"
import { createHash } from "node:crypto"
import { existsSync, mkdirSync, readFileSync, readdirSync } from "node:fs"
import { fileURLToPath } from "node:url"
import { dirname, resolve, sep } from "node:path"

const artifact = dirname(fileURLToPath(import.meta.url))
const baseline = JSON.parse(readFileSync(resolve(artifact, "baseline-manifest.json"), "utf8"))
const source = JSON.parse(readFileSync(resolve(artifact, "source-manifest.json"), "utf8"))
if (process.argv.length !== 4) throw new Error("Usage: node prepare.mjs <local-repository> <empty-output-directory>")
const repository = resolve(process.argv[2])
const target = resolve(process.argv[3])
if (target === repository || target.startsWith(`${repository}${sep}`) || target === baseline.source_workspace || target.startsWith(`${baseline.source_workspace}${sep}`)) throw new Error("The output must be an independent empty directory")
if (existsSync(target) && readdirSync(target).length !== 0) throw new Error("Output directory is not empty")
mkdirSync(target, { recursive: true })
execFileSync("git", ["-C", repository, "cat-file", "-e", `${baseline.original_head}^{commit}`])
const original = execFileSync("git", ["-C", repository, "archive", "--format=tar", baseline.original_head], { maxBuffer: 64 * 1024 * 1024 })
execFileSync("tar", ["-xf", "-", "-C", target], { input: original })
const names = execFileSync("tar", ["-tzf", resolve(artifact, "baseline-overlay.tar.gz")], { encoding: "utf8" }).trim().split("\n").sort()
const expected = baseline.files.map((file) => file.path).sort()
if (JSON.stringify(names) !== JSON.stringify(expected)) throw new Error("Baseline archive entries differ from the exact manifest")
execFileSync("tar", ["-xzf", resolve(artifact, "baseline-overlay.tar.gz"), "-C", target])
const hash = (path) => createHash("sha256").update(readFileSync(path)).digest("hex")
for (const file of baseline.files) if (hash(resolve(target, file.path)) !== file.sha256) throw new Error(`Baseline hash mismatch: ${file.path}`)
execFileSync("git", ["apply", "--check", resolve(artifact, "labels-source.patch")], { cwd: target })
execFileSync("git", ["apply", resolve(artifact, "labels-source.patch")], { cwd: target })
for (const file of source.files) if (hash(resolve(target, file.path)) !== file.sha256) throw new Error(`Source hash mismatch: ${file.path}`)
console.log(`Prepared exact source snapshot ${source.source_commit} in ${target}. No services, database, credentials, or repository state were changed.`)
