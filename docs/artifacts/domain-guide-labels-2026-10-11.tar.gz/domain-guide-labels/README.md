# Labels：独立模块指南验收 artifact

仅用于独立代码目录重放。Labels 演示没有加入产品 Root；本包不代表生产部署、发行或全仓所有业务用例验收。

- 原始仓库 HEAD：`9880af6f40a0c9884305c27a1a5a5a717b253fe7`。
- 精确框架基线 snapshot：`00a636df1d5d3a8d5704491575ac178a53e52cad`，284 个相对原始 HEAD 的源码文件。
- 已验收演示源码 snapshot：`55b6b2c406eb513cb86159f75240efa160c5bcdf`，41 个演示及正式生成文件。
- Node `26.8.2` / pnpm `12.11.2`；依赖使用 frozen lockfile。
- overlay 捕获不包含 ignored、真实 `.env`、密钥、依赖、构建产物或 `.git`；原始 HEAD 中的公开配置样例仍是源码样例。没有网络上传或远端操作。

`baseline-manifest.json` 与 `source-manifest.json` 逐文件提供 SHA256。`baseline-overlay.tar.gz` 是精确基线，`labels-source.patch` 是相对基线的完整演示差异，`guide.patch` 仅包含可整合到产品的指南修订。`evidence` 包含实际 red/green、正式检查日志和仅登录后的业务截图。

## 重放源码

传入能读取原始 HEAD 的本地仓库，以及不存在或为空的独立输出目录：

```sh
node prepare.mjs /absolute/path/to/enterprise-admin /absolute/path/to/empty-labels-checkout
```

脚本只读取 Git 原始树、准备独立源码目录、校验清单/patch/hash。它不修改源仓库，不复制工作区凭据，不启动服务或执行数据库操作。成功后在输出目录继续运行正式命令。

## 生成与验证命令

```sh
pnpm install --frozen-lockfile
pnpm db:check
pnpm api:openapi
pnpm api:generate
pnpm api:check
pnpm --filter @workspace/i18n exec i18next-cli types
pnpm i18n:check
pnpm lint
pnpm typecheck
pnpm --filter docs check:content
pnpm build
pnpm test:database
pnpm exec vitest run --config vitest.config.mjs --project api tests/api/labels-guide.test.mjs
pnpm exec vitest run --config vitest.config.e2e.mjs tests/e2e/labels-guide.test.mjs
pnpm --filter storybook exec vitest run --config vitest.config.ts ../tenant/src/features/labels/labels.stories.tsx
```

本次 PostgreSQL/Redis 来自既有正式 Testcontainers fixture：真实 bootstrap、`app_migrator` one-shot migration 和 `app_runtime` HTTP。Docker 必须可用，Chromium 使用仓库声明的 Playwright 版本。macOS 本次使用 `DOCKER_HOST=unix:///Users/huanancao/.orbstack/run/docker.sock`；这只是本机 Docker 连接，不是应用数据库配置。

本机 CLI 已验证前缀为 `PATH=/private/tmp/framework-pnpm-probe/node_modules/.bin:/Users/huanancao/.nvm/versions/node/v26.8.2/bin:$PATH`。其他机器按 package.json 配置同版本 CLI，不依赖这两个本机目录。

HTTP 聚焦用例 8/8，真实浏览器 4/4，同一正式 Feature 的 Storybook 7/7，完整数据库 110/110；全仓 lint/typecheck 均 22/22，完整构建 12/12，翻译 983 个键/13 个 namespace，文档内容 38 页。未将聚焦 API/E2E 结果写成所有 API/E2E 用例通过；未重跑全仓 unit/API/E2E 套件。
